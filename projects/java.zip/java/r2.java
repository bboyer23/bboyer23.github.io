public class r2 {
	

	public static void main(String[] args){

		/*

			 Write a program that prints integers from 10 through 1 using a while loop. 
			 Use compound assignment or increment/decrement operators to update variables 
			 (wherever possible).


		*/ 

		int end_value = 10;

		int counter = 1;

		while(end_value >= counter){


			System.out.println(end_value);
			end_value--;

		}




	}
}