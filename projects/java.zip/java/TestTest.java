public class TestTest {
	
	
	public static void main(String[] args){


		Test test = new Test();

		System.out.println(test);

		Test user1 = new Test("Welcome!","Whats 1+1","John");

		System.out.println(user1);



	}
}