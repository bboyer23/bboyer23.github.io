public class r4 {
	
	public static void main(String[] args){

		// print a sequence using a while loop


		int counter = 1;

		while(counter <= 10){

			System.out.print(counter);
			System.out.print(" ");
			counter++;

		}
		System.out.println();

	}
}