public class TestArrayObject {
	
	public static void main(String[] args){


			
	}
}