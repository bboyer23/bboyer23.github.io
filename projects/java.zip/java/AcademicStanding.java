public enum AcademicStanding {
	

	STOPPED_OUT,
	GOOD,
	PASSING,
	FAILING
}