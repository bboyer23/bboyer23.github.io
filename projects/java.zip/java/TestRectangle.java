public class TestRectangle {

	public static void main(String[] args){

		Rectangle myRect = new Rectangle();

		myRect.setLength(3);
		myRect.setWidth(14);

		System.out.println(myRect);
	}
}