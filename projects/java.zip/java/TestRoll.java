public class TestRoll {
	
	public static void main(String[] args){

		RollTheDice roller1 = new RollTheDice(1,6);
		dice.roll();

		System.out.println(roller1);
	}
}