/****
 * 
 * 	Name: Benjamin Boyer
 * 	Date: March 28th, 2024
 * 	
 * 	Purpose: Midterm exam tester class 
 * 
 * 
 * 
 * 
 * */

public class PlayLottery {
	
	public static void main(String[] args){

			MassLottery p1 = new MassLottery();


			p1.Spin();
			p1.Draw();
	}
}