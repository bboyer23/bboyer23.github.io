public class charArray {
	
	public static void main(String[] args){


		// practice ascii value defintions

		
	}
}