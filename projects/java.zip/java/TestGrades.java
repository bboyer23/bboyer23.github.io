public class TestGrades {
	
	public static void main(String[] args){

		// create grades object

		Grades semester_1 = new Grades();

		// print out values in grade object
		// this calls for an override of the toString method

		System.out.println(semester_1);
	}
}