/****
 * 
 * 	Name: Benjamin Boyer
 * 	Date: March 28th, 2024
 * 	
 * 	Purpose: Midterm exam tester class
 * 
 * 
 * 
 * 
 * */

public class Shop {

	public static void main(String[] args){

		AmazonStore purchase1 = new AmazonStore();

		purchase1.showProducts();
		purchase1.processOrder();
	}
}