public class AcademicTest {
	
	public static void main(String[] args){

		AcademicStanding standing = AcademicStanding.GOOD;
		AcademicStanding standing1 = AcademicStanding.STOPPED_OUT;
		System.out.println("Current academic standing: " + standing);
	}
}